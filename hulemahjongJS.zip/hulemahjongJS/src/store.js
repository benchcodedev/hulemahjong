const fs = require('fs');
const os = require('os');
const path = require('path');
const { buildInitialData } = require('./seedData');

const primaryPath = path.join(__dirname, '..', 'data', 'db.json');
const fallbackPath = path.join(os.tmpdir(), 'hulemahjong-db.json');

let activeDbPath = primaryPath;
let memoryDb = null;

function resolveDbPath() {
  try {
    const dir = path.dirname(primaryPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.accessSync(dir, fs.constants.W_OK);
    activeDbPath = primaryPath;
  } catch (_) {
    activeDbPath = fallbackPath;
  }
}

resolveDbPath();

function loadDb() {
  if (memoryDb) return memoryDb;
  try {
    if (fs.existsSync(activeDbPath)) {
      const raw = fs.readFileSync(activeDbPath, 'utf8');
      memoryDb = JSON.parse(raw);
      return memoryDb;
    }
  } catch (_) {}

  memoryDb = buildInitialData();
  saveDb();
  return memoryDb;
}

function saveDb() {
  if (!memoryDb) return;
  try {
    fs.writeFileSync(activeDbPath, JSON.stringify(memoryDb, null, 2), 'utf8');
  } catch (_) {
    try {
      activeDbPath = fallbackPath;
      fs.writeFileSync(activeDbPath, JSON.stringify(memoryDb, null, 2), 'utf8');
    } catch (__) {}
  }
}

function nextId(entityKey) {
  const db = loadDb();
  db.counters[entityKey] = (db.counters[entityKey] || 0) + 1;
  return db.counters[entityKey];
}

function formatRupiah(amount) {
  const n = Math.max(0, Math.round(Number(amount) || 0));
  return 'Rp ' + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

module.exports = {
  loadDb,
  saveDb,
  nextId,
  formatRupiah
};

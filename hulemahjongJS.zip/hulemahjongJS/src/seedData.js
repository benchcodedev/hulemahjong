function addDaysStr(daysOffset) {
  const d = new Date();
  d.setDate(d.getDate() + daysOffset);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function buildInitialData() {
  const today = addDaysStr(0);
  const tomorrow = addDaysStr(1);

  return {
    counters: {
      category: 4,
      table: 15,
      slot: 8,
      promo: 2,
      booking: 4,
      event: 3,
      registration: 0,
      gallery: 7,
      plan: 3,
      application: 0,
      inquiry: 1
    },
    adminUser: {
      email: process.env.ADMIN_EMAIL || 'admin@hulemahjong.id',
      password: process.env.ADMIN_PASSWORD || 'password123',
      name: 'Hule Concierge Admin'
    },
    siteSettings: {
      brand_prefix: 'Hule',
      brand_suffix: 'Mahjong',
      site_tagline: 'Elevated Social Mahjong Lounge & Private Suites',
      house_policy: 'Strictly recreational & strategic point play. Gambling of any kind is prohibited.',
      cancellation_note: 'Free rescheduling up to 24h before session time.',
      banner_eyebrow: '2026 MEMBERSHIP — LIMITED PLACES',
      banner_title_line1_bold: 'Your First',
      banner_title_line1_light: 'Round',
      banner_title_line2_light: 'Starts',
      banner_title_line2_bold: 'Here.',
      banner_description: 'A curated number of Hule Club memberships open each season. Submit your application for priority automatic table reservations, VIP suite access, and tournament invitations.',
      banner_image: '/images/mahjong/cta-banner.jpg',
      contact_address: 'Rukan La Riviera PIK 2, Tangerang & Jl. M. Isa, Palembang',
      contact_phone: '+62 812-8899-7788',
      contact_whatsapp: '6281288997788',
      contact_email: 'concierge@hulemahjong.id',
      contact_instagram: 'https://instagram.com/hulemahjong.id',
      opening_hours: 'Daily 10:00 – 24:00 WIB',
      payment_bank_name: 'BCA (Bank Central Asia)',
      payment_account_number: '8830-9918-27',
      payment_account_holder: 'PT Hule Mahjong Indonesia'
    },
    timeSlots: [
      { id: 1, start_time: '10:00', label: '10:00', is_peak: false, is_active: true, sort_order: 1 },
      { id: 2, start_time: '11:30', label: '11:30', is_peak: false, is_active: true, sort_order: 2 },
      { id: 3, start_time: '13:00', label: '13:00', is_peak: false, is_active: true, sort_order: 3 },
      { id: 4, start_time: '14:30', label: '14:30', is_peak: false, is_active: true, sort_order: 4 },
      { id: 5, start_time: '16:00', label: '16:00', is_peak: false, is_active: true, sort_order: 5 },
      { id: 6, start_time: '17:30', label: '17:30', is_peak: true, is_active: true, sort_order: 6 },
      { id: 7, start_time: '19:30', label: '19:30', is_peak: true, is_active: true, sort_order: 7 },
      { id: 8, start_time: '21:30', label: '21:30', is_peak: true, is_active: true, sort_order: 8 }
    ],
    tableCategories: [
      {
        id: 1,
        name: 'Regular Social Lounge',
        slug: 'regular-social-lounge',
        branch: 'PIK 2 — La Riviera',
        subtitle: 'Open Social Hall • Whisper-Quiet Auto Table',
        description: 'Bright, architecturally curated open lounge featuring whisper-quiet automatic mahjong tables, ergonomic seating, and full artisanal tea & dim sum service.',
        weekday_price: 87000,
        weekend_price: 115000,
        peak_surcharge: 15000,
        session_minutes: 120,
        min_players: 4,
        max_players: 5,
        image_path: '/images/mahjong/lounge-regular.jpg',
        amenities: ['Automatic Shuffler Table', 'Score Reference Cards', 'USB-C Table Charging', 'F&B Table Service'],
        is_active: true,
        sort_order: 1
      },
      {
        id: 2,
        name: 'Private VIP Suite',
        slug: 'private-vip-suite',
        branch: 'PIK 2 — La Riviera',
        subtitle: '3×3m Enclosed Acoustic Room • Dedicated Butler Call',
        description: 'Intimate private 3×3m suite wrapped in warm champagne oak and acoustic travertine panels. Ideal for uninterrupted rounds with friends and complimentary hot oolong.',
        weekday_price: 175000,
        weekend_price: 225000,
        peak_surcharge: 25000,
        session_minutes: 120,
        min_players: 4,
        max_players: 6,
        image_path: '/images/mahjong/vip-suite.jpg',
        amenities: ['Private Acoustic Room', 'Treyo Ultra-Silent Auto Table', 'Complimentary Oolong Pot', 'Bluetooth Lounge Audio', 'Air Purifier'],
        is_active: true,
        sort_order: 2
      },
      {
        id: 3,
        name: 'Imperial VVIP Salon',
        slug: 'imperial-vvip-salon',
        branch: 'PIK 2 — La Riviera',
        subtitle: 'Grand Private Salon • Tea Bar & Lounge Sofa',
        description: 'Our flagship private sanctuary featuring bespoke champagne-gold automatic mahjong hardware, private lounge sofa seating, artisanal tea service, and priority host attention.',
        weekday_price: 295000,
        weekend_price: 360000,
        peak_surcharge: 35000,
        session_minutes: 120,
        min_players: 4,
        max_players: 8,
        image_path: '/images/mahjong/vvip-imperial.jpg',
        amenities: ['Grand Private Salon', 'Bespoke Gold Series Table', 'Lounge Sofa & Tea Bar', 'Complimentary Dim Sum Platter', 'Dedicated Concierge'],
        is_active: true,
        sort_order: 3
      },
      {
        id: 4,
        name: 'Palembang Social Lounge',
        slug: 'palembang-social-lounge',
        branch: 'Palembang — Jl. M. Isa',
        subtitle: 'Main Club Hall • Beginner & Pro Friendly',
        description: 'Located on Jl. M. Isa Palembang with 15 modern automatic mahjong tables, friendly table hosts for newcomers, and signature refreshments.',
        weekday_price: 50000,
        weekend_price: 70000,
        peak_surcharge: 10000,
        session_minutes: 120,
        min_players: 4,
        max_players: 5,
        image_path: '/images/mahjong/lounge-regular.jpg',
        amenities: ['Automatic Shuffler Table', 'Beginner Rule Guide', 'F&B Menu Access', 'Free Wi-Fi'],
        is_active: true,
        sort_order: 4
      }
    ],
    mahjongTables: [
      { id: 1, table_category_id: 1, code: 'REG-01', name: 'Social Auto #01', floor_zone: '1F — Main Lounge', machine_model: 'Hule Whisper-Pro S1', status: 'active' },
      { id: 2, table_category_id: 1, code: 'REG-02', name: 'Social Auto #02', floor_zone: '1F — Main Lounge', machine_model: 'Hule Whisper-Pro S1', status: 'active' },
      { id: 3, table_category_id: 1, code: 'REG-03', name: 'Social Auto #03', floor_zone: '1F — Main Lounge', machine_model: 'Hule Whisper-Pro S1', status: 'active' },
      { id: 4, table_category_id: 1, code: 'REG-04', name: 'Social Auto #04', floor_zone: '1F — Main Lounge', machine_model: 'Hule Whisper-Pro S1', status: 'active' },
      { id: 5, table_category_id: 1, code: 'REG-05', name: 'Social Auto #05', floor_zone: '1F — Main Lounge', machine_model: 'Hule Whisper-Pro S1', status: 'active' },
      { id: 6, table_category_id: 1, code: 'REG-06', name: 'Social Auto #06', floor_zone: '1F — Window Bay', machine_model: 'Hule Whisper-Pro S1', status: 'maintenance' },
      { id: 7, table_category_id: 2, code: 'VIP-01', name: 'VIP Sakura Suite', floor_zone: '2F — Private Wing', machine_model: 'Treyo Champagne Silent', status: 'active' },
      { id: 8, table_category_id: 2, code: 'VIP-02', name: 'VIP Jade Suite', floor_zone: '2F — Private Wing', machine_model: 'Treyo Champagne Silent', status: 'active' },
      { id: 9, table_category_id: 2, code: 'VIP-03', name: 'VIP Alabaster Suite', floor_zone: '2F — Private Wing', machine_model: 'Treyo Champagne Silent', status: 'active' },
      { id: 10, table_category_id: 3, code: 'VVIP-01', name: 'Imperial Salon East', floor_zone: '3F — Penthouse Wing', machine_model: 'Hule Bespoke Gold Edition', status: 'active' },
      { id: 11, table_category_id: 3, code: 'VVIP-02', name: 'Imperial Salon West', floor_zone: '3F — Penthouse Wing', machine_model: 'Hule Bespoke Gold Edition', status: 'active' },
      { id: 12, table_category_id: 4, code: 'PLB-01', name: 'Palembang Auto #01', floor_zone: 'Main Hall', machine_model: 'Hule Whisper-Pro S1', status: 'active' },
      { id: 13, table_category_id: 4, code: 'PLB-02', name: 'Palembang Auto #02', floor_zone: 'Main Hall', machine_model: 'Hule Whisper-Pro S1', status: 'active' },
      { id: 14, table_category_id: 4, code: 'PLB-03', name: 'Palembang Auto #03', floor_zone: 'Main Hall', machine_model: 'Hule Whisper-Pro S1', status: 'active' },
      { id: 15, table_category_id: 4, code: 'PLB-04', name: 'Palembang Auto #04', floor_zone: 'Main Hall', machine_model: 'Hule Whisper-Pro S1', status: 'active' }
    ],
    promoCodes: [
      { id: 1, code: 'HULE10', description: '10% Welcome Discount (up to Rp 50.000)', discount_type: 'percentage', discount_value: 10, max_discount: 50000, usage_limit: 200, used_count: 0, valid_until: addDaysStr(180), is_active: true },
      { id: 2, code: 'FIRSTROUND', description: 'Rp 20.000 off your first mahjong session', discount_type: 'fixed', discount_value: 20000, max_discount: null, usage_limit: 100, used_count: 0, valid_until: addDaysStr(180), is_active: true }
    ],
    bookings: [
      { id: 1, booking_code: 'HLM-DEMO-VIP1', table_category_id: 2, mahjong_table_id: 7, customer_name: 'Clarissa Tanoto', customer_phone: '081280001101', customer_email: 'clarissa@example.com', booking_date: tomorrow, start_time: '13:00', end_time: '15:00', sessions_count: 1, duration_minutes: 120, players_count: 4, base_price: 175000, discount_amount: 0, promo_code: null, total_price: 175000, status: 'confirmed', payment_status: 'paid', payment_method: 'qris_transfer', payment_proof_path: null, notes: null, created_at: new Date().toISOString() },
      { id: 2, booking_code: 'HLM-DEMO-VIP2', table_category_id: 2, mahjong_table_id: 8, customer_name: 'Kevin Wijaya', customer_phone: '081280001102', customer_email: 'kevin@example.com', booking_date: tomorrow, start_time: '13:00', end_time: '15:00', sessions_count: 1, duration_minutes: 120, players_count: 4, base_price: 175000, discount_amount: 0, promo_code: null, total_price: 175000, status: 'confirmed', payment_status: 'paid', payment_method: 'qris_transfer', payment_proof_path: null, notes: null, created_at: new Date().toISOString() },
      { id: 3, booking_code: 'HLM-DEMO-VIP3', table_category_id: 2, mahjong_table_id: 9, customer_name: 'Michelle Halim', customer_phone: '081280001103', customer_email: 'michelle@example.com', booking_date: tomorrow, start_time: '13:00', end_time: '15:00', sessions_count: 1, duration_minutes: 120, players_count: 4, base_price: 175000, discount_amount: 0, promo_code: null, total_price: 175000, status: 'confirmed', payment_status: 'paid', payment_method: 'qris_transfer', payment_proof_path: null, notes: null, created_at: new Date().toISOString() },
      { id: 4, booking_code: 'HLM-DEMO-REG1', table_category_id: 1, mahjong_table_id: 1, customer_name: 'Brandon Kusuma', customer_phone: '081299887766', customer_email: 'brandon@example.com', booking_date: today, start_time: '19:30', end_time: '21:30', sessions_count: 1, duration_minutes: 120, players_count: 4, base_price: 102000, discount_amount: 0, promo_code: null, total_price: 102000, status: 'confirmed', payment_status: 'paid', payment_method: 'qris_transfer', payment_proof_path: null, notes: null, created_at: new Date().toISOString() }
    ],
    events: [
      {
        id: 1,
        slug: 'hule-champagne-cup-2026',
        title: 'Hule Champagne Cup — Autumn Championship',
        category: 'Tournament',
        event_date: addDaysStr(10),
        start_time: '13:00',
        end_time: '19:00',
        location: 'Hule Mahjong PIK 2 — Main Salon',
        price: 250000,
        quota: 32,
        registered_count: 24,
        image_path: '/images/mahjong/event-tournament.jpg',
        excerpt: 'Four-round strategic point tournament featuring automatic tables, official referees, bespoke trophies, and afternoon dim sum reception.',
        description: 'Join our flagship seasonal tournament celebrating pure strategic tile play. Players compete across four timed 60-minute rounds using official Hule recreational point scoring.\n\nEntry includes welcome specialty oolong tea, artisanal dim sum reception, tournament scorecard kit, and eligibility for the Hule Champagne Trophy & VIP lounge credits.',
        is_featured: true,
        is_active: true
      },
      {
        id: 2,
        slug: 'mahjong-101-guided-beginner-clinic',
        title: 'Mahjong 101: Guided Beginner & Etiquette Clinic',
        category: 'Beginner Coaching',
        event_date: addDaysStr(4),
        start_time: '15:00',
        end_time: '17:30',
        location: 'Hule Mahjong PIK 2 — Coaching Lounge',
        price: 125000,
        quota: 16,
        registered_count: 9,
        image_path: '/images/mahjong/event-coaching.jpg',
        excerpt: 'Never called "Hule" before? Learn tile suits, melds, automatic table etiquette, and winning hand patterns with our patient table coaches.',
        description: 'Designed specifically for complete newcomers and casual players looking to build confidence. Our resident hosts walk you step-by-step through tile recognition, Chow/Pung/Kong combinations, how automatic mahjong tables work, and your first guided practice rounds.',
        is_featured: true,
        is_active: true
      },
      {
        id: 3,
        slug: 'friday-tiles-and-tea-social-mixer',
        title: 'Friday Night Tiles & Artisanal Tea Social',
        category: 'Social Night',
        event_date: addDaysStr(7),
        start_time: '19:00',
        end_time: '22:00',
        location: 'Hule Mahjong PIK 2 & Palembang',
        price: 95000,
        quota: 28,
        registered_count: 18,
        image_path: '/images/mahjong/gallery-fnb.jpg',
        excerpt: 'Solo-player friendly Friday evening mixer! Rotate tables every hour, meet fellow mahjong enthusiasts, and enjoy curated cold-brew teas.',
        description: 'No full group of four? No problem. Friday Night Tiles & Tea matches solo and duo players into balanced tables based on comfort level. Includes 3 hours of open play plus a complimentary signature iced latte or oolong pot.',
        is_featured: false,
        is_active: true
      }
    ],
    eventRegistrations: [],
    galleries: [
      { id: 1, title: 'Main Social Lounge — PIK 2', category: 'Lounge & Interior', caption: 'Sunlit champagne-oak architecture with whisper-quiet automatic tables.', image_path: '/images/mahjong/lounge-regular.jpg', is_featured: true, is_active: true, sort_order: 1 },
      { id: 2, title: 'Private VIP Acoustic Suite', category: 'VIP Suites', caption: 'Enclosed 3×3m VIP suites crafted for intimate four-player sessions.', image_path: '/images/mahjong/vip-suite.jpg', is_featured: true, is_active: true, sort_order: 2 },
      { id: 3, title: 'Imperial Penthouse VVIP Salon', category: 'VIP Suites', caption: 'Bespoke gold-series automatic mahjong table with private lounge seating.', image_path: '/images/mahjong/vvip-imperial.jpg', is_featured: true, is_active: true, sort_order: 3 },
      { id: 4, title: 'Seasonal Point Championship', category: 'Tournaments & Community', caption: 'Competitive recreational strategy rounds in our main hall.', image_path: '/images/mahjong/event-tournament.jpg', is_featured: true, is_active: true, sort_order: 4 },
      { id: 5, title: 'Beginner Coaching & Tile Mastery', category: 'Tournaments & Community', caption: 'Hands-on coaching clinics guiding newcomers to their first winning hand.', image_path: '/images/mahjong/event-coaching.jpg', is_featured: false, is_active: true, sort_order: 5 },
      { id: 6, title: 'Artisanal Tea & Dim Sum Service', category: 'Food & Beverage', caption: 'Roasted tieguanyin oolong, layered iced lattes, and handmade dim sum tableside.', image_path: '/images/mahjong/gallery-fnb.jpg', is_featured: true, is_active: true, sort_order: 6 },
      { id: 7, title: 'Ivory & Champagne Tile Craft', category: 'Lounge & Interior', caption: 'Custom-weighted tournament tiles engineered for effortless tactile play.', image_path: '/images/mahjong/cta-banner.jpg', is_featured: false, is_active: true, sort_order: 7 }
    ],
    membershipPlans: [
      {
        id: 1,
        slug: 'social-club-pass',
        name: 'Social Club',
        badge: 'Essential',
        price: 450000,
        billing_period: 'per quarter',
        description: 'Tailored for regular weekday & weekend players who enjoy our open social lounge.',
        benefits: ['15% off all Regular Social Lounge sessions', 'Priority 7-day advance slot booking', 'Complimentary hot oolong tea on every visit', 'Free entry to 1 Friday Social Mixer per month'],
        is_featured: false,
        is_active: true,
        sort_order: 1
      },
      {
        id: 2,
        slug: 'jade-privilege-member',
        name: 'Jade Privilege',
        badge: 'Most Popular',
        price: 1150000,
        billing_period: 'per quarter',
        description: 'Our signature tier combining complimentary VIP suite hours, peak waivers, and event priority.',
        benefits: ['3× Complimentary 2-Hour Private VIP Suite vouchers', '20% off Regular & VIP Suite bookings anytime', 'Peak-hour surcharge waived on all bookings', '14-day priority reservation window', 'Priority registration for Hule Championships'],
        is_featured: true,
        is_active: true,
        sort_order: 2
      },
      {
        id: 3,
        slug: 'grandmaster-vip-circle',
        name: 'Grandmaster Circle',
        badge: 'Limited Intake',
        price: 3800000,
        billing_period: 'per year',
        description: 'By-application annual patronage with Imperial VVIP Salon privileges and personal tile locker.',
        benefits: ['10× Complimentary 2-Hour VIP / Imperial VVIP sessions', '25% privilege rate across PIK 2 & Palembang lounges', 'Dedicated engraved personal mahjong tile locker', 'Complimentary entry to all seasonal tournaments', 'Direct WhatsApp Concierge line for same-day holds'],
        is_featured: false,
        is_active: true,
        sort_order: 3
      }
    ],
    membershipApplications: [],
    inquiries: [
      { id: 1, name: 'Natasha Lim', phone: '08119203344', email: 'natasha.lim@example.com', subject: 'Private Corporate Mahjong Gathering (16 Guests)', message: 'Hi Hule team, we would like to book 4 tables for a private team social next Friday afternoon with dim sum catering. Could you share package options?', is_read: false, created_at: new Date().toISOString() }
    ]
  };
}

module.exports = { buildInitialData };

const { loadDb, formatRupiah } = require('./store');

function timeToMinutes(hhmm) {
  const [h, m] = String(hhmm || '10:00').split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

function minutesToTime(totalMinutes) {
  const norm = ((totalMinutes % 1440) + 1440) % 1440;
  const h = Math.floor(norm / 60);
  const m = norm % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function isWeekendDate(dateStr) {
  const [y, m, d] = String(dateStr).split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  const day = dt.getDay();
  return day === 0 || day === 6;
}

function formatDateNice(dateStr, withWeekday = false) {
  const [y, m, d] = String(dateStr).split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const base = `${months[dt.getMonth()]} ${String(dt.getDate()).padStart(2, '0')}, ${dt.getFullYear()}`;
  return withWeekday ? `${days[dt.getDay()]}, ${base}` : base;
}

function getAvailableTables(categoryId, dateStr, startTime, durationMinutes, excludeBookingId = null) {
  const db = loadDb();
  const activeTables = db.mahjongTables
    .filter(t => t.table_category_id === Number(categoryId) && t.status === 'active')
    .sort((a, b) => a.code.localeCompare(b.code));

  if (!activeTables.length) return [];

  const reqStart = timeToMinutes(startTime);
  const reqEnd = reqStart + durationMinutes;

  const existing = db.bookings.filter(
    b => b.table_category_id === Number(categoryId)
      && b.booking_date === dateStr
      && b.status !== 'cancelled'
      && (!excludeBookingId || b.id !== Number(excludeBookingId))
  );

  const occupiedIds = new Set();
  let unassigned = 0;

  for (const b of existing) {
    const bStart = timeToMinutes(b.start_time);
    const bEnd = bStart + Number(b.duration_minutes || 120);
    if (reqStart < bEnd && reqEnd > bStart) {
      if (b.mahjong_table_id) occupiedIds.add(Number(b.mahjong_table_id));
      else unassigned++;
    }
  }

  let free = activeTables.filter(t => !occupiedIds.has(t.id));
  if (unassigned > 0) free = free.slice(unassigned);
  return free;
}

function calculatePricing(category, dateStr, startTime, sessionsCount = 1, promoCodeStr = '') {
  const db = loadDb();
  const sessions = Math.max(1, Math.min(6, Number(sessionsCount) || 1));
  const weekend = isWeekendDate(dateStr);
  const slotObj = db.timeSlots.find(s => s.start_time === startTime);
  const isPeak = slotObj ? Boolean(slotObj.is_peak) : timeToMinutes(startTime) >= 18 * 60;

  const sessionRate = weekend ? Number(category.weekend_price) : Number(category.weekday_price);
  const peakPerSession = isPeak ? Number(category.peak_surcharge || 0) : 0;
  const basePrice = (sessionRate + peakPerSession) * sessions;

  let discountAmount = 0;
  let appliedCode = null;
  let promoValid = false;
  let promoMessage = null;

  const cleanPromo = String(promoCodeStr || '').trim().toUpperCase();
  if (cleanPromo) {
    const promo = db.promoCodes.find(p => p.code === cleanPromo);
    const notExpired = !promo?.valid_until || promo.valid_until >= new Date().toISOString().slice(0, 10);
    const withinLimit = !promo?.usage_limit || promo.used_count < promo.usage_limit;

    if (promo && promo.is_active && notExpired && withinLimit) {
      if (promo.discount_type === 'percentage') {
        discountAmount = Math.round(basePrice * (Number(promo.discount_value) / 100));
        if (promo.max_discount && discountAmount > promo.max_discount) {
          discountAmount = Number(promo.max_discount);
        }
      } else {
        discountAmount = Number(promo.discount_value);
      }
      discountAmount = Math.min(discountAmount, basePrice);
      appliedCode = promo.code;
      promoValid = true;
      promoMessage = `Promo ${promo.code} applied (-${formatRupiah(discountAmount)})`;
    } else {
      promoMessage = 'Promo code is invalid or expired.';
    }
  }

  const totalPrice = Math.max(0, basePrice - discountAmount);
  const durationMinutes = Number(category.session_minutes || 120) * sessions;
  const endTime = minutesToTime(timeToMinutes(startTime) + durationMinutes);

  return {
    is_weekend: weekend,
    rate_label: weekend ? 'Weekend Rate' : 'Weekday Rate',
    is_peak: isPeak,
    session_rate: sessionRate,
    peak_surcharge: peakPerSession * sessions,
    sessions_count: sessions,
    duration_minutes: durationMinutes,
    start_time: startTime,
    end_time: endTime,
    base_price: basePrice,
    discount_amount: discountAmount,
    promo_code: appliedCode,
    promo_valid: promoValid,
    promo_message: promoMessage,
    total_price: totalPrice,
    formatted_base: formatRupiah(basePrice),
    formatted_discount: formatRupiah(discountAmount),
    formatted_total: formatRupiah(totalPrice)
  };
}

function getSlotsAvailability(category, dateStr, sessionsCount = 1) {
  const db = loadDb();
  const slots = db.timeSlots
    .filter(s => s.is_active)
    .sort((a, b) => (a.sort_order - b.sort_order) || a.start_time.localeCompare(b.start_time));

  const totalTables = db.mahjongTables.filter(t => t.table_category_id === category.id && t.status === 'active').length;
  const durationMinutes = Number(category.session_minutes || 120) * Math.max(1, Number(sessionsCount) || 1);
  const now = new Date();
  const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const nowMinutes = now.getHours() * 60 + now.getMinutes() - 15;

  return slots.map(slot => {
    const free = getAvailableTables(category.id, dateStr, slot.start_time, durationMinutes);
    const pricing = calculatePricing(category, dateStr, slot.start_time, sessionsCount);
    const isPast = dateStr < todayStr || (dateStr === todayStr && timeToMinutes(slot.start_time) < nowMinutes);
    const remaining = isPast ? 0 : free.length;

    return {
      id: slot.id,
      start_time: slot.start_time,
      label: slot.label,
      is_peak: Boolean(slot.is_peak),
      available: remaining > 0,
      is_past: isPast,
      remaining_tables: remaining,
      total_tables: totalTables,
      price: pricing.total_price,
      formatted_price: pricing.formatted_total
    };
  });
}

function generateBookingCode() {
  const db = loadDb();
  const now = new Date();
  const ymd = `${String(now.getFullYear()).slice(-2)}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  do {
    let rand = '';
    for (let i = 0; i < 4; i++) rand += chars[Math.floor(Math.random() * chars.length)];
    code = `HLM-${ymd}-${rand}`;
  } while (db.bookings.some(b => b.booking_code === code));
  return code;
}

module.exports = {
  timeToMinutes,
  minutesToTime,
  formatDateNice,
  getAvailableTables,
  calculatePricing,
  getSlotsAvailability,
  generateBookingCode
};

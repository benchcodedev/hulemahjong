require('dotenv').config();
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const ejs = require('ejs');

const { loadDb, saveDb, nextId, formatRupiah } = require('./src/store');
const {
  timeToMinutes,
  formatDateNice,
  getAvailableTables,
  calculatePricing,
  getSlotsAvailability,
  generateBookingCode
} = require('./src/bookingService');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || 'hule-mahjong-benchcode-secret-2026';

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Support Laravel-style _method override in HTML forms
app.use((req, res, next) => {
  const methodOverride = req.body?._method || req.query?._method;
  if (methodOverride && typeof methodOverride === 'string') {
    req.method = methodOverride.toUpperCase();
  }
  next();
});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 6 * 1024 * 1024 }
});

function saveUploadedFile(file, subfolder) {
  if (!file || !file.buffer) return null;
  const ext = (path.extname(file.originalname || '') || '.jpg').toLowerCase().replace(/[^.a-z0-9]/g, '') || '.jpg';
  const fileName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
  const relUrl = `/uploads/${subfolder}/${fileName}`;
  const diskTarget = path.join(__dirname, 'public', 'uploads', subfolder, fileName);

  try {
    fs.mkdirSync(path.dirname(diskTarget), { recursive: true });
    fs.writeFileSync(diskTarget, file.buffer);
    return relUrl;
  } catch (_) {
    const mime = file.mimetype || 'image/jpeg';
    return `data:${mime};base64,${file.buffer.toString('base64')}`;
  }
}

function slugify(str) {
  return String(str || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || `item-${Date.now()}`;
}

function todayStrOffset(days = 0) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function formatDateDMY(dateStr) {
  if (!dateStr) return '-';
  const [y, m, d] = String(dateStr).split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${String(dt.getDate()).padStart(2, '0')} ${months[dt.getMonth()]} ${dt.getFullYear()}`;
}

function formatDateEventCard(dateStr) {
  if (!dateStr) return '-';
  const [y, m, d] = String(dateStr).split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${days[dt.getDay()]}, ${String(dt.getDate()).padStart(2, '0')} ${months[dt.getMonth()]} ${dt.getFullYear()}`;
}

function formatDateFull(dateStr) {
  if (!dateStr) return '-';
  const [y, m, d] = String(dateStr).split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return `${days[dt.getDay()]}, ${String(dt.getDate()).padStart(2, '0')} ${months[dt.getMonth()]} ${dt.getFullYear()}`;
}

function signToken(email) {
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(email).digest('hex');
  return `${Buffer.from(email).toString('base64url')}.${sig}`;
}

function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [b64, sig] = token.split('.');
  const email = Buffer.from(b64, 'base64url').toString('utf8');
  const expected = crypto.createHmac('sha256', SESSION_SECRET).update(email).digest('hex');
  if (sig !== expected) return null;
  return email;
}

function setFlash(res, type, message) {
  const payload = JSON.stringify({ type, message });
  res.cookie('hule_flash', payload, { httpOnly: true, path: '/', maxAge: 30000 });
}

// Hydrate helpers matching Laravel Eloquent accessors
function hydrateCategory(cat, db) {
  if (!cat) return null;
  const tables = db.mahjongTables
    .filter(t => t.table_category_id === cat.id)
    .sort((a, b) => a.code.localeCompare(b.code));
  const activeTables = tables.filter(t => t.status === 'active');
  return {
    ...cat,
    image_url: cat.image_path || '/images/mahjong/lounge-regular.jpg',
    formatted_weekday_price: formatRupiah(cat.weekday_price),
    formatted_weekend_price: formatRupiah(cat.weekend_price),
    tables,
    tables_count: tables.length,
    active_tables_count: activeTables.length
  };
}

function hydrateBooking(b, db) {
  if (!b) return null;
  const catRaw = db.tableCategories.find(c => c.id === b.table_category_id);
  const category = catRaw ? hydrateCategory(catRaw, db) : null;
  const table = db.mahjongTables.find(t => t.id === b.mahjong_table_id) || null;
  return {
    ...b,
    category,
    table,
    formatted_total: formatRupiah(b.total_price),
    formatted_base: formatRupiah(b.base_price),
    formatted_discount: formatRupiah(b.discount_amount),
    payment_proof_url: b.payment_proof_path || null,
    date_dmy: formatDateDMY(b.booking_date),
    date_card: formatDateNice(b.booking_date, true)
  };
}

function hydrateEvent(ev) {
  if (!ev) return null;
  const remaining = Math.max(0, Number(ev.quota || 0) - Number(ev.registered_count || 0));
  return {
    ...ev,
    image_url: ev.image_path || '/images/mahjong/event-tournament.jpg',
    formatted_price: Number(ev.price) > 0 ? formatRupiah(ev.price) : 'Free Entry',
    remaining_seats: remaining,
    date_card: formatDateEventCard(ev.event_date),
    date_full: formatDateFull(ev.event_date)
  };
}

function hydrateGallery(g) {
  return {
    ...g,
    image_url: g.image_path || '/images/mahjong/lounge-regular.jpg'
  };
}

function hydratePlan(p) {
  return {
    ...p,
    formatted_price: formatRupiah(p.price)
  };
}

// Global request locals middleware
app.use((req, res, next) => {
  const db = loadDb();
  let flash = null;
  if (req.cookies.hule_flash) {
    try { flash = JSON.parse(req.cookies.hule_flash); } catch (_) {}
    res.clearCookie('hule_flash', { path: '/' });
  }

  const adminEmail = verifyToken(req.cookies.hule_admin);
  const currentAdmin = adminEmail
    ? { email: adminEmail, name: db.adminUser?.name || 'Hule Concierge Admin' }
    : null;

  req.currentAdmin = currentAdmin;
  res.locals.siteSettings = db.siteSettings || {};
  res.locals.currentAdmin = currentAdmin;
  res.locals.flashSuccess = flash?.type === 'success' ? flash.message : null;
  res.locals.flashError = flash?.type === 'error' ? flash.message : null;
  res.locals.currentPath = req.path;
  res.locals.formatRupiah = formatRupiah;
  res.locals.formatDateDMY = formatDateDMY;
  res.locals.formatDateNice = formatDateNice;
  res.locals.todayStrOffset = todayStrOffset;
  next();
});

async function renderPublic(res, viewName, data = {}) {
  const viewPath = path.join(__dirname, 'views', 'public', `${viewName}.ejs`);
  const merged = { ...res.locals, ...data };
  const body = await ejs.renderFile(viewPath, merged);
  const layoutPath = path.join(__dirname, 'views', 'layouts', 'public.ejs');
  const html = await ejs.renderFile(layoutPath, {
    ...merged,
    body,
    title: data.title || `${merged.siteSettings.brand_prefix || 'Hule'}${merged.siteSettings.brand_suffix || 'Mahjong'} — Elevated Social Mahjong Lounge`,
    hideCtaBanner: Boolean(data.hideCtaBanner),
    pageScripts: data.pageScripts || ''
  });
  res.send(html);
}

async function renderAdmin(res, viewName, data = {}) {
  const db = loadDb();
  const pendingBookingsCount = db.bookings.filter(b => b.status === 'pending' || b.payment_status === 'waiting_verification').length;
  const pendingMembershipsCount = db.membershipApplications.filter(a => a.status === 'pending').length;
  const unreadInquiriesCount = db.inquiries.filter(i => !i.is_read).length;

  const viewPath = path.join(__dirname, 'views', 'admin', `${viewName}.ejs`);
  const merged = {
    ...res.locals,
    pendingBookingsCount,
    pendingMembershipsCount,
    unreadInquiriesCount,
    ...data
  };
  const body = await ejs.renderFile(viewPath, merged);
  const layoutPath = path.join(__dirname, 'views', 'layouts', 'admin.ejs');
  const html = await ejs.renderFile(layoutPath, {
    ...merged,
    body,
    title: data.title || 'CMS Admin — Hule Mahjong',
    heading: data.heading || 'Dashboard',
    subheading: data.subheading || 'Manage reservations, table inventory, pricing, events, and media.',
    headerActions: data.headerActions || ''
  });
  res.send(html);
}

function requireAdmin(req, res, next) {
  if (!req.currentAdmin) {
    return res.redirect('/admin/login');
  }
  next();
}

/* =========================================================================
   PUBLIC WEBSITE & INTERACTIVE BOOKING SYSTEM ROUTES
   ========================================================================= */

app.get('/', async (req, res) => {
  const db = loadDb();
  const categories = db.tableCategories
    .filter(c => c.is_active)
    .sort((a, b) => (a.sort_order - b.sort_order) || (a.id - b.id))
    .map(c => hydrateCategory(c, db));

  let selectedCategory = categories[0] || null;
  if (req.query.category && categories.length) {
    const found = categories.find(c => c.slug === req.query.category || String(c.id) === String(req.query.category));
    if (found) selectedCategory = found;
  }

  const defaultDate = todayStrOffset(1);
  const daysShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const monthsShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const dates = [];
  for (let i = 0; i < 21; i++) {
    const dStr = todayStrOffset(i);
    const [y, m, d] = dStr.split('-').map(Number);
    const dt = new Date(y, m - 1, d);
    dates.push({
      date: dStr,
      day_short: daysShort[dt.getDay()],
      day_num: String(d),
      month_short: `${monthsShort[dt.getMonth()]} ${y}`
    });
  }

  let slots = [];
  let defaultTime = '13:00';
  let initialPricing = null;

  if (selectedCategory) {
    slots = getSlotsAvailability(selectedCategory, defaultDate, 1);
    const firstAvail = slots.find(s => s.available);
    defaultTime = firstAvail ? firstAvail.start_time : (slots[0]?.start_time || '13:00');
    initialPricing = calculatePricing(selectedCategory, defaultDate, defaultTime, 1);
  }

  await renderPublic(res, 'reserve', {
    title: 'Reserve Mahjong Table — Hule Mahjong',
    activeNav: 'home',
    categories,
    selectedCategory,
    dates,
    slots,
    defaultDate,
    defaultTime,
    initialPricing,
    defaultDateFormatted: formatDateNice(defaultDate, false)
  });
});

app.get('/api/booking-availability', (req, res) => {
  const db = loadDb();
  const categoryId = Number(req.query.table_category_id);
  const catRaw = db.tableCategories.find(c => c.id === categoryId) || db.tableCategories[0];
  if (!catRaw) return res.status(404).json({ error: 'Category not found' });

  const category = hydrateCategory(catRaw, db);
  const dateStr = String(req.query.date || todayStrOffset(1));
  const sessions = Math.max(1, Math.min(6, Number(req.query.sessions_count) || 1));
  const promoCode = String(req.query.promo_code || '');

  const slots = getSlotsAvailability(category, dateStr, sessions);
  let selectedTime = String(req.query.start_time || '13:00');
  let selectedSlot = slots.find(s => s.start_time === selectedTime);

  if (!selectedSlot || !selectedSlot.available) {
    const firstOpen = slots.find(s => s.available);
    if (firstOpen) {
      selectedSlot = firstOpen;
      selectedTime = firstOpen.start_time;
    } else if (slots[0]) {
      selectedSlot = slots[0];
      selectedTime = slots[0].start_time;
    }
  }

  const pricing = calculatePricing(category, dateStr, selectedTime, sessions, promoCode);

  res.json({
    category: {
      id: category.id,
      name: category.name,
      branch: category.branch,
      image_url: category.image_url,
      min_players: category.min_players,
      max_players: category.max_players
    },
    date: dateStr,
    date_formatted: formatDateNice(dateStr, false),
    slots,
    selected_time: selectedTime,
    selected_slot_available: Boolean(selectedSlot && selectedSlot.available),
    remaining_tables: selectedSlot ? selectedSlot.remaining_tables : 0,
    pricing
  });
});

app.post('/bookings', (req, res) => {
  const db = loadDb();
  const categoryId = Number(req.body.table_category_id);
  const category = db.tableCategories.find(c => c.id === categoryId && c.is_active);
  if (!category) {
    setFlash(res, 'error', 'Selected table category is invalid.');
    return res.redirect('/');
  }

  const dateStr = String(req.body.booking_date || todayStrOffset(1));
  const startTime = String(req.body.start_time || '13:00');
  const sessions = Math.max(1, Math.min(6, Number(req.body.sessions_count) || 1));
  const players = Math.max(1, Math.min(12, Number(req.body.players_count) || 4));
  const promoInput = String(req.body.promo_code || '').trim();
  const customerName = String(req.body.customer_name || '').trim();
  const customerPhone = String(req.body.customer_phone || '').trim();

  if (!customerName || !customerPhone) {
    setFlash(res, 'error', 'Please enter your full name and WhatsApp number.');
    return res.redirect('/');
  }

  const pricing = calculatePricing(category, dateStr, startTime, sessions, promoInput);
  const freeTables = getAvailableTables(category.id, dateStr, startTime, pricing.duration_minutes);
  if (!freeTables.length) {
    setFlash(res, 'error', 'Sorry, all automatic tables in this suite were just booked for that time slot.');
    return res.redirect('/');
  }

  const assignedTable = freeTables[0];
  const bookingCode = generateBookingCode();
  const paymentMethod = req.body.payment_method === 'pay_at_lounge' ? 'pay_at_lounge' : 'qris_transfer';

  if (pricing.promo_valid && pricing.promo_code) {
    const pObj = db.promoCodes.find(p => p.code === pricing.promo_code);
    if (pObj) pObj.used_count = (pObj.used_count || 0) + 1;
  }

  const newBooking = {
    id: nextId('booking'),
    booking_code: bookingCode,
    table_category_id: category.id,
    mahjong_table_id: assignedTable.id,
    customer_name: customerName,
    customer_phone: customerPhone,
    customer_email: String(req.body.customer_email || '').trim() || null,
    booking_date: dateStr,
    start_time: pricing.start_time,
    end_time: pricing.end_time,
    sessions_count: pricing.sessions_count,
    duration_minutes: pricing.duration_minutes,
    players_count: players,
    base_price: pricing.base_price,
    discount_amount: pricing.discount_amount,
    promo_code: pricing.promo_code,
    total_price: pricing.total_price,
    status: paymentMethod === 'pay_at_lounge' ? 'confirmed' : 'pending',
    payment_status: 'unpaid',
    payment_method: paymentMethod,
    payment_proof_path: null,
    notes: String(req.body.notes || '').trim() || null,
    created_at: new Date().toISOString()
  };

  db.bookings.unshift(newBooking);
  saveDb();

  setFlash(res, 'success', `Table ${assignedTable.code} reserved! Reference: ${bookingCode}`);
  res.redirect(`/booking/${bookingCode}`);
});

app.get('/check-booking', (req, res) => {
  const code = String(req.query.booking_code || '').trim().toUpperCase();
  if (!code) return res.redirect('/contact#lookup');
  const db = loadDb();
  const found = db.bookings.find(b => b.booking_code.toUpperCase() === code);
  if (!found) {
    setFlash(res, 'error', `Booking reference "${code}" was not found. Please check your code.`);
    return res.redirect('/contact#lookup');
  }
  res.redirect(`/booking/${found.booking_code}`);
});

app.get('/booking/:bookingCode', async (req, res) => {
  const db = loadDb();
  const code = String(req.params.bookingCode || '').toUpperCase();
  const raw = db.bookings.find(b => b.booking_code.toUpperCase() === code);
  if (!raw) {
    setFlash(res, 'error', 'Booking pass not found.');
    return res.redirect('/');
  }
  const booking = hydrateBooking(raw, db);
  const now = new Date();
  const issuedStamp = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  await renderPublic(res, 'booking-pass', {
    title: `Booking Pass ${booking.booking_code} — Hule Mahjong`,
    activeNav: 'home',
    booking,
    issuedStamp
  });
});

app.post('/booking/:bookingCode/payment-proof', upload.single('payment_proof'), (req, res) => {
  const db = loadDb();
  const code = String(req.params.bookingCode || '').toUpperCase();
  const raw = db.bookings.find(b => b.booking_code.toUpperCase() === code);
  if (!raw) return res.redirect('/');

  const uploadedUrl = saveUploadedFile(req.file, 'payments');
  if (uploadedUrl) {
    raw.payment_proof_path = uploadedUrl;
    raw.payment_status = 'waiting_verification';
    if (raw.status === 'pending') raw.status = 'confirmed';
    saveDb();
    setFlash(res, 'success', 'Payment transfer receipt uploaded! Our concierge will verify shortly.');
  } else {
    setFlash(res, 'error', 'Please choose a valid JPG/PNG receipt image.');
  }
  res.redirect(`/booking/${raw.booking_code}`);
});

app.get('/tables', async (req, res) => {
  const db = loadDb();
  const categories = db.tableCategories
    .filter(c => c.is_active)
    .sort((a, b) => (a.sort_order - b.sort_order) || (a.id - b.id))
    .map(c => hydrateCategory(c, db));

  await renderPublic(res, 'tables', {
    title: 'Suites & Automatic Tables — Hule Mahjong',
    activeNav: 'tables',
    categories
  });
});

app.get('/membership', async (req, res) => {
  const db = loadDb();
  const plans = db.membershipPlans
    .filter(p => p.is_active)
    .sort((a, b) => (a.sort_order - b.sort_order) || (a.id - b.id))
    .map(hydratePlan);

  await renderPublic(res, 'membership', {
    title: 'Club Membership — Hule Mahjong',
    activeNav: 'membership',
    hideCtaBanner: true,
    plans
  });
});

app.post('/membership/apply', (req, res) => {
  const db = loadDb();
  db.membershipApplications.unshift({
    id: nextId('application'),
    membership_plan_id: Number(req.body.membership_plan_id),
    applicant_name: String(req.body.applicant_name || '').trim(),
    applicant_phone: String(req.body.applicant_phone || '').trim(),
    applicant_email: String(req.body.applicant_email || '').trim(),
    preferred_branch: String(req.body.preferred_branch || 'PIK 2 — La Riviera'),
    playing_frequency: String(req.body.playing_frequency || '1-2 times / week'),
    message: String(req.body.message || '').trim() || null,
    status: 'pending',
    created_at: new Date().toISOString()
  });
  saveDb();
  setFlash(res, 'success', 'Thank you! Your Hule Club Membership application has been received by our Membership Secretary.');
  res.redirect('/membership');
});

app.get('/events', async (req, res) => {
  const db = loadDb();
  const selectedCategory = String(req.query.category || 'All');
  const categories = ['All', 'Tournament', 'Beginner Coaching', 'Social Night'];

  let events = db.events
    .filter(e => e.is_active)
    .sort((a, b) => a.event_date.localeCompare(b.event_date))
    .map(hydrateEvent);

  if (selectedCategory !== 'All') {
    events = events.filter(e => e.category === selectedCategory);
  }

  await renderPublic(res, 'events', {
    title: 'Events, Championships & Coaching — Hule Mahjong',
    activeNav: 'events',
    categories,
    selectedCategory,
    events
  });
});

app.get('/events/:slug', async (req, res) => {
  const db = loadDb();
  const raw = db.events.find(e => e.slug === req.params.slug && e.is_active);
  if (!raw) {
    setFlash(res, 'error', 'Event not found.');
    return res.redirect('/events');
  }
  await renderPublic(res, 'event-detail', {
    title: `${raw.title} — Hule Mahjong`,
    activeNav: 'events',
    event: hydrateEvent(raw)
  });
});

app.post('/events/:slug/register', (req, res) => {
  const db = loadDb();
  const raw = db.events.find(e => e.slug === req.params.slug && e.is_active);
  if (!raw) return res.redirect('/events');

  const seats = Math.max(1, Math.min(4, Number(req.body.seats) || 1));
  const remaining = Math.max(0, Number(raw.quota) - Number(raw.registered_count || 0));
  if (seats > remaining) {
    setFlash(res, 'error', 'Not enough seats remaining for this event.');
    return res.redirect(`/events/${raw.slug}`);
  }

  const regCode = `EVT-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  raw.registered_count = Number(raw.registered_count || 0) + seats;
  db.eventRegistrations.unshift({
    id: nextId('registration'),
    event_id: raw.id,
    registration_code: regCode,
    participant_name: String(req.body.participant_name || '').trim(),
    participant_phone: String(req.body.participant_phone || '').trim(),
    participant_email: String(req.body.participant_email || '').trim() || null,
    skill_level: String(req.body.skill_level || 'Intermediate'),
    seats,
    total_price: Number(raw.price || 0) * seats,
    notes: String(req.body.notes || '').trim() || null,
    created_at: new Date().toISOString()
  });
  saveDb();
  setFlash(res, 'success', `Seat confirmed! Your event registration code is ${regCode}.`);
  res.redirect(`/events/${raw.slug}`);
});

app.get('/gallery', async (req, res) => {
  const db = loadDb();
  const selectedCategory = String(req.query.category || 'All');
  const categories = ['All', 'Lounge & Interior', 'VIP Suites', 'Tournaments & Community', 'Food & Beverage'];

  let photos = db.galleries
    .filter(g => g.is_active)
    .sort((a, b) => (a.sort_order - b.sort_order) || (a.id - b.id))
    .map(hydrateGallery);

  if (selectedCategory !== 'All') {
    photos = photos.filter(p => p.category === selectedCategory);
  }

  await renderPublic(res, 'gallery', {
    title: 'Lounge & Interior Gallery — Hule Mahjong',
    activeNav: 'gallery',
    categories,
    selectedCategory,
    photos
  });
});

app.get('/contact', async (req, res) => {
  await renderPublic(res, 'contact', {
    title: 'Locations, Booking Lookup & Concierge — Hule Mahjong',
    activeNav: 'contact'
  });
});

app.post('/contact', (req, res) => {
  const db = loadDb();
  db.inquiries.unshift({
    id: nextId('inquiry'),
    name: String(req.body.name || '').trim(),
    phone: String(req.body.phone || '').trim(),
    email: String(req.body.email || '').trim() || null,
    subject: String(req.body.subject || 'General Lounge Inquiry'),
    message: String(req.body.message || '').trim(),
    is_read: false,
    created_at: new Date().toISOString()
  });
  saveDb();
  setFlash(res, 'success', 'Message sent! Our Hule Concierge team will reach out via WhatsApp shortly.');
  res.redirect('/contact');
});

/* =========================================================================
   ADMIN AUTHENTICATION & CMS ROUTES
   ========================================================================= */

app.get('/admin/login', (req, res) => {
  if (req.currentAdmin) return res.redirect('/admin');
  res.render('admin/login', { error: res.locals.flashError });
});

app.post('/admin/login', (req, res) => {
  const db = loadDb();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const validEmail = (process.env.ADMIN_EMAIL || db.adminUser?.email || 'admin@hulemahjong.id').toLowerCase();
  const validPass = process.env.ADMIN_PASSWORD || db.adminUser?.password || 'password123';

  if (email === validEmail && password === validPass) {
    res.cookie('hule_admin', signToken(email), {
      httpOnly: true,
      path: '/',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });
    return res.redirect('/admin');
  }
  setFlash(res, 'error', 'Invalid admin email or password.');
  res.redirect('/admin/login');
});

app.post('/admin/logout', (req, res) => {
  res.clearCookie('hule_admin', { path: '/' });
  res.redirect('/admin/login');
});

// Admin Dashboard
app.get('/admin', requireAdmin, async (req, res) => {
  const db = loadDb();
  const today = todayStrOffset(0);
  const scheduleDate = String(req.query.date || today);
  const ymPrefix = today.slice(0, 7);

  const todayBookingsCount = db.bookings.filter(b => b.booking_date === today && b.status !== 'cancelled').length;
  const monthRevenue = db.bookings
    .filter(b => b.booking_date.startsWith(ymPrefix) && b.status !== 'cancelled')
    .reduce((sum, b) => sum + Number(b.total_price || 0), 0);

  const totalTables = db.mahjongTables.length;
  const activeTablesCount = db.mahjongTables.filter(t => t.status === 'active').length;
  const maintenanceTablesCount = db.mahjongTables.filter(t => t.status === 'maintenance').length;
  const upcomingEventsCount = db.events.filter(e => e.is_active).length;
  const galleryCount = db.galleries.length;
  const pendingAppsCount = db.membershipApplications.filter(a => a.status === 'pending').length;

  const slots = db.timeSlots.filter(s => s.is_active).sort((a, b) => a.sort_order - b.sort_order);
  const tables = db.mahjongTables
    .map(t => ({ ...t, category: db.tableCategories.find(c => c.id === t.table_category_id) }))
    .sort((a, b) => a.code.localeCompare(b.code));

  const dayBookings = db.bookings.filter(b => b.booking_date === scheduleDate && b.status !== 'cancelled');
  const matrix = {};
  for (const t of tables) {
    matrix[t.id] = {};
    for (const s of slots) {
      const slotMin = timeToMinutes(s.start_time);
      const match = dayBookings.find(b => {
        if (b.mahjong_table_id !== t.id) return false;
        const bStart = timeToMinutes(b.start_time);
        const bEnd = bStart + Number(b.duration_minutes || 120);
        return slotMin >= bStart && slotMin < bEnd;
      });
      matrix[t.id][s.start_time] = match || null;
    }
  }

  const recentBookings = db.bookings.slice(0, 8).map(b => hydrateBooking(b, db));
  const now = new Date();
  const monthsLong = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  await renderAdmin(res, 'dashboard', {
    activeCms: 'dashboard',
    title: 'Dashboard — Hule Mahjong CMS',
    heading: 'Executive Overview & Live Floor',
    subheading: 'Monitor real-time automatic table occupancy, revenue, and bookings.',
    headerActions: `<a href="/admin/tables" class="px-4 py-2 rounded-full bg-[#c3b091] hover:bg-[#b59f7c] text-[#141310] text-xs font-semibold transition">+ Manage Tables & Prices</a>`,
    todayBookingsCount,
    monthRevenue,
    currentMonthYear: `${monthsLong[now.getMonth()]} ${now.getFullYear()}`,
    activeTablesCount,
    totalTables,
    maintenanceTablesCount,
    upcomingEventsCount,
    galleryCount,
    pendingAppsCount,
    scheduleDate,
    scheduleDateNice: formatDateEventCard(scheduleDate),
    slots,
    tables,
    matrix,
    recentBookings
  });
});

// Admin Bookings
app.get('/admin/bookings', requireAdmin, async (req, res) => {
  const db = loadDb();
  const search = String(req.query.search || '').trim().toLowerCase();
  const filterDate = String(req.query.date || '').trim();
  const filterStatus = String(req.query.status || 'all');

  let bookings = db.bookings.map(b => hydrateBooking(b, db));
  if (search) {
    bookings = bookings.filter(b =>
      b.booking_code.toLowerCase().includes(search) ||
      b.customer_name.toLowerCase().includes(search) ||
      b.customer_phone.toLowerCase().includes(search)
    );
  }
  if (filterDate) bookings = bookings.filter(b => b.booking_date === filterDate);
  if (filterStatus && filterStatus !== 'all') bookings = bookings.filter(b => b.status === filterStatus);

  const categories = db.tableCategories.map(c => hydrateCategory(c, db));
  const slots = db.timeSlots.filter(s => s.is_active).sort((a, b) => a.sort_order - b.sort_order);

  await renderAdmin(res, 'bookings', {
    activeCms: 'bookings',
    title: 'Bookings Management — Hule Mahjong CMS',
    heading: 'Reservations & Walk-Ins',
    subheading: 'Verify transfers, reassign automatic tables, or create walk-in bookings.',
    headerActions: `<button type="button" onclick="document.getElementById('walkin-panel').classList.toggle('hidden')" class="px-4 py-2 rounded-full bg-[#111] hover:bg-[#c3b091] text-white hover:text-[#141310] text-xs font-semibold transition">+ New Walk-In Booking</button>`,
    bookings,
    categories,
    slots,
    allTables: db.mahjongTables,
    query: { search: req.query.search || '', date: filterDate, status: filterStatus }
  });
});

app.post('/admin/bookings/walk-in', requireAdmin, (req, res) => {
  const db = loadDb();
  const category = db.tableCategories.find(c => c.id === Number(req.body.table_category_id));
  if (!category) return res.redirect('/admin/bookings');

  const dateStr = String(req.body.booking_date || todayStrOffset(0));
  const startTime = String(req.body.start_time || '13:00');
  const sessions = Math.max(1, Number(req.body.sessions_count) || 1);
  const pricing = calculatePricing(category, dateStr, startTime, sessions);
  const free = getAvailableTables(category.id, dateStr, startTime, pricing.duration_minutes);

  const code = generateBookingCode();
  db.bookings.unshift({
    id: nextId('booking'),
    booking_code: code,
    table_category_id: category.id,
    mahjong_table_id: free[0] ? free[0].id : null,
    customer_name: String(req.body.customer_name || 'Walk-In Guest').trim(),
    customer_phone: String(req.body.customer_phone || '-').trim(),
    customer_email: null,
    booking_date: dateStr,
    start_time: pricing.start_time,
    end_time: pricing.end_time,
    sessions_count: sessions,
    duration_minutes: pricing.duration_minutes,
    players_count: Number(req.body.players_count) || 4,
    base_price: pricing.base_price,
    discount_amount: 0,
    promo_code: null,
    total_price: pricing.total_price,
    status: 'confirmed',
    payment_status: req.body.payment_status === 'unpaid' ? 'unpaid' : 'paid',
    payment_method: 'walk_in',
    payment_proof_path: null,
    notes: 'Walk-in created via CMS',
    created_at: new Date().toISOString()
  });
  saveDb();
  setFlash(res, 'success', `Walk-in booking ${code} created.`);
  res.redirect('/admin/bookings');
});

app.put('/admin/bookings/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  const b = db.bookings.find(x => x.id === Number(req.params.id));
  if (b) {
    b.mahjong_table_id = req.body.mahjong_table_id ? Number(req.body.mahjong_table_id) : null;
    b.status = String(req.body.status || b.status);
    b.payment_status = String(req.body.payment_status || b.payment_status);
    saveDb();
    setFlash(res, 'success', `Booking ${b.booking_code} updated.`);
  }
  res.redirect('/admin/bookings');
});

app.delete('/admin/bookings/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  db.bookings = db.bookings.filter(x => x.id !== Number(req.params.id));
  saveDb();
  setFlash(res, 'success', 'Booking deleted.');
  res.redirect('/admin/bookings');
});

// Admin Tables & Dynamic Pricing
app.get('/admin/tables', requireAdmin, async (req, res) => {
  const db = loadDb();
  const categories = db.tableCategories
    .sort((a, b) => (a.sort_order - b.sort_order) || (a.id - b.id))
    .map(c => hydrateCategory(c, db));

  await renderAdmin(res, 'tables', {
    activeCms: 'tables',
    title: 'Tables & Pricing — Hule Mahjong CMS',
    heading: 'Tables, Suites & Dynamic Pricing',
    subheading: 'Set weekday/weekend/peak session rates, upload suite photos, and add/remove physical automatic tables.',
    headerActions: `<button type="button" onclick="document.getElementById('new-cat-panel').classList.toggle('hidden')" class="px-4 py-2 rounded-full bg-[#111] hover:bg-[#c3b091] text-white hover:text-[#141310] text-xs font-semibold transition">+ Add New Suite / Category</button>`,
    categories
  });
});

app.post('/admin/tables/categories', requireAdmin, upload.single('image'), (req, res) => {
  const db = loadDb();
  const id = nextId('category');
  const name = String(req.body.name || 'New Suite').trim();
  const uploaded = saveUploadedFile(req.file, 'tables');
  const amenities = String(req.body.amenities_raw || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);

  db.tableCategories.push({
    id,
    name,
    slug: slugify(name),
    branch: String(req.body.branch || 'PIK 2 — La Riviera').trim(),
    subtitle: String(req.body.subtitle || '').trim(),
    description: String(req.body.description || '').trim(),
    weekday_price: Number(req.body.weekday_price) || 100000,
    weekend_price: Number(req.body.weekend_price) || 130000,
    peak_surcharge: Number(req.body.peak_surcharge) || 0,
    session_minutes: Number(req.body.session_minutes) || 120,
    min_players: Number(req.body.min_players) || 4,
    max_players: Number(req.body.max_players) || 6,
    image_path: uploaded || '/images/mahjong/vip-suite.jpg',
    amenities,
    is_active: true,
    sort_order: db.tableCategories.length + 1
  });

  const initialCount = Math.max(0, Math.min(30, Number(req.body.initial_tables_count) || 0));
  const prefix = name.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'TBL';
  for (let i = 1; i <= initialCount; i++) {
    db.mahjongTables.push({
      id: nextId('table'),
      table_category_id: id,
      code: `${prefix}-${String(i).padStart(2, '0')}`,
      name: `${name} #${String(i).padStart(2, '0')}`,
      floor_zone: 'Main Lounge',
      machine_model: 'Hule Whisper-Pro S1',
      status: 'active'
    });
  }

  saveDb();
  setFlash(res, 'success', `Suite category "${name}" created with ${initialCount} table(s).`);
  res.redirect('/admin/tables');
});

app.put('/admin/tables/categories/:id', requireAdmin, upload.single('image'), (req, res) => {
  const db = loadDb();
  const cat = db.tableCategories.find(c => c.id === Number(req.params.id));
  if (cat) {
    cat.name = String(req.body.name || cat.name).trim();
    cat.branch = String(req.body.branch || cat.branch).trim();
    cat.weekday_price = Number(req.body.weekday_price) || 0;
    cat.weekend_price = Number(req.body.weekend_price) || 0;
    cat.peak_surcharge = Number(req.body.peak_surcharge) || 0;
    cat.session_minutes = Number(req.body.session_minutes) || 120;
    cat.min_players = Number(req.body.min_players) || 4;
    cat.max_players = Number(req.body.max_players) || 6;
    cat.subtitle = String(req.body.subtitle || '').trim();
    cat.description = String(req.body.description || '').trim();
    cat.amenities = String(req.body.amenities_raw || '')
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);
    cat.is_active = Boolean(req.body.is_active);

    const uploaded = saveUploadedFile(req.file, 'tables');
    if (uploaded) cat.image_path = uploaded;

    saveDb();
    setFlash(res, 'success', `Pricing & details saved for "${cat.name}".`);
  }
  res.redirect('/admin/tables');
});

app.delete('/admin/tables/categories/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  const catId = Number(req.params.id);
  db.tableCategories = db.tableCategories.filter(c => c.id !== catId);
  db.mahjongTables = db.mahjongTables.filter(t => t.table_category_id !== catId);
  saveDb();
  setFlash(res, 'success', 'Category and its physical tables removed.');
  res.redirect('/admin/tables');
});

app.post('/admin/tables/categories/:id/quick-add', requireAdmin, (req, res) => {
  const db = loadDb();
  const cat = db.tableCategories.find(c => c.id === Number(req.params.id));
  if (cat) {
    const existing = db.mahjongTables.filter(t => t.table_category_id === cat.id);
    const prefix = existing[0] ? existing[0].code.split('-')[0] : (cat.name.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'TBL');
    const nextNum = existing.length + 1;
    let code = `${prefix}-${String(nextNum).padStart(2, '0')}`;
    let counter = nextNum;
    while (db.mahjongTables.some(t => t.code === code)) {
      counter++;
      code = `${prefix}-${String(counter).padStart(2, '0')}`;
    }
    db.mahjongTables.push({
      id: nextId('table'),
      table_category_id: cat.id,
      code,
      name: `${cat.name} #${String(counter).padStart(2, '0')}`,
      floor_zone: existing[0]?.floor_zone || 'Main Lounge',
      machine_model: 'Hule Whisper-Pro S1',
      status: 'active'
    });
    saveDb();
    setFlash(res, 'success', `Added automatic table ${code} to ${cat.name}.`);
  }
  res.redirect('/admin/tables');
});

app.post('/admin/tables/categories/:id/quick-remove', requireAdmin, (req, res) => {
  const db = loadDb();
  const catId = Number(req.params.id);
  const catTables = db.mahjongTables.filter(t => t.table_category_id === catId);
  if (catTables.length > 0) {
    const last = catTables[catTables.length - 1];
    db.mahjongTables = db.mahjongTables.filter(t => t.id !== last.id);
    saveDb();
    setFlash(res, 'success', `Removed table unit ${last.code}.`);
  }
  res.redirect('/admin/tables');
});

app.post('/admin/tables/categories/:id/items', requireAdmin, (req, res) => {
  const db = loadDb();
  const catId = Number(req.params.id);
  const code = String(req.body.code || '').trim().toUpperCase();
  if (code) {
    db.mahjongTables.push({
      id: nextId('table'),
      table_category_id: catId,
      code,
      name: String(req.body.name || code).trim(),
      floor_zone: String(req.body.floor_zone || 'Main Lounge').trim(),
      machine_model: 'Hule Whisper-Pro S1',
      status: String(req.body.status || 'active')
    });
    saveDb();
    setFlash(res, 'success', `Custom table ${code} added.`);
  }
  res.redirect('/admin/tables');
});

app.put('/admin/tables/items/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  const tbl = db.mahjongTables.find(t => t.id === Number(req.params.id));
  if (tbl) {
    tbl.name = String(req.body.name || tbl.name).trim();
    tbl.floor_zone = String(req.body.floor_zone || tbl.floor_zone).trim();
    tbl.status = String(req.body.status || tbl.status);
    saveDb();
    setFlash(res, 'success', `Table ${tbl.code} updated.`);
  }
  res.redirect('/admin/tables');
});

app.delete('/admin/tables/items/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  db.mahjongTables = db.mahjongTables.filter(t => t.id !== Number(req.params.id));
  saveDb();
  setFlash(res, 'success', 'Table unit deleted.');
  res.redirect('/admin/tables');
});

// Admin Time Slots & Promo Codes
app.get('/admin/slots-promos', requireAdmin, async (req, res) => {
  const db = loadDb();
  const slots = [...db.timeSlots].sort((a, b) => (a.sort_order - b.sort_order) || a.start_time.localeCompare(b.start_time));
  await renderAdmin(res, 'slots-promos', {
    activeCms: 'slots',
    title: 'Time Slots & Promo Codes — Hule Mahjong CMS',
    heading: 'Operating Time Slots & Promo Vouchers',
    subheading: 'Configure session start times, peak-hour surcharges, and discount codes.',
    slots,
    promoCodes: db.promoCodes
  });
});

app.post('/admin/slots', requireAdmin, (req, res) => {
  const db = loadDb();
  const startTime = String(req.body.start_time || '').trim();
  if (startTime) {
    db.timeSlots.push({
      id: nextId('slot'),
      start_time: startTime,
      label: String(req.body.label || startTime).trim(),
      is_peak: Boolean(req.body.is_peak),
      is_active: true,
      sort_order: db.timeSlots.length + 1
    });
    saveDb();
    setFlash(res, 'success', `Time slot ${startTime} added.`);
  }
  res.redirect('/admin/slots-promos');
});

app.put('/admin/slots/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  const s = db.timeSlots.find(x => x.id === Number(req.params.id));
  if (s) {
    s.sort_order = Number(req.body.sort_order) || 1;
    s.start_time = String(req.body.start_time || s.start_time).trim();
    s.label = String(req.body.label || s.start_time).trim();
    s.is_peak = Boolean(req.body.is_peak);
    s.is_active = Boolean(req.body.is_active);
    saveDb();
    setFlash(res, 'success', `Slot ${s.label} updated.`);
  }
  res.redirect('/admin/slots-promos');
});

app.delete('/admin/slots/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  db.timeSlots = db.timeSlots.filter(x => x.id !== Number(req.params.id));
  saveDb();
  setFlash(res, 'success', 'Time slot deleted.');
  res.redirect('/admin/slots-promos');
});

app.post('/admin/promos', requireAdmin, (req, res) => {
  const db = loadDb();
  const code = String(req.body.code || '').trim().toUpperCase();
  if (code) {
    db.promoCodes.unshift({
      id: nextId('promo'),
      code,
      description: String(req.body.description || '').trim(),
      discount_type: req.body.discount_type === 'fixed' ? 'fixed' : 'percentage',
      discount_value: Number(req.body.discount_value) || 10,
      max_discount: req.body.max_discount ? Number(req.body.max_discount) : null,
      usage_limit: 200,
      used_count: 0,
      valid_until: req.body.valid_until || null,
      is_active: true
    });
    saveDb();
    setFlash(res, 'success', `Promo voucher ${code} created.`);
  }
  res.redirect('/admin/slots-promos');
});

app.post('/admin/promos/:id/toggle', requireAdmin, (req, res) => {
  const db = loadDb();
  const p = db.promoCodes.find(x => x.id === Number(req.params.id));
  if (p) {
    p.is_active = !p.is_active;
    saveDb();
  }
  res.redirect('/admin/slots-promos');
});

app.delete('/admin/promos/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  db.promoCodes = db.promoCodes.filter(x => x.id !== Number(req.params.id));
  saveDb();
  setFlash(res, 'success', 'Promo code deleted.');
  res.redirect('/admin/slots-promos');
});

// Admin Events
app.get('/admin/events', requireAdmin, async (req, res) => {
  const db = loadDb();
  const events = db.events.map(hydrateEvent);
  const registrations = db.eventRegistrations.map(r => ({
    ...r,
    event: db.events.find(e => e.id === r.event_id) || null
  }));

  await renderAdmin(res, 'events', {
    activeCms: 'events',
    title: 'Events & Coaching — Hule Mahjong CMS',
    heading: 'Events, Tournaments & Coaching Clinics',
    subheading: 'Publish mahjong tournaments, beginner coaching classes, and track participant registrations.',
    headerActions: `<button type="button" onclick="document.getElementById('new-event-panel').classList.toggle('hidden')" class="px-4 py-2 rounded-full bg-[#111] hover:bg-[#c3b091] text-white hover:text-[#141310] text-xs font-semibold transition">+ Publish New Event</button>`,
    events,
    registrations
  });
});

app.post('/admin/events', requireAdmin, upload.single('image'), (req, res) => {
  const db = loadDb();
  const title = String(req.body.title || 'New Event').trim();
  const uploaded = saveUploadedFile(req.file, 'events');
  db.events.unshift({
    id: nextId('event'),
    slug: `${slugify(title)}-${Math.random().toString(36).slice(2, 5)}`,
    title,
    category: String(req.body.category || 'Tournament'),
    event_date: String(req.body.event_date || todayStrOffset(7)),
    start_time: String(req.body.start_time || '14:00'),
    end_time: String(req.body.end_time || '18:00'),
    location: String(req.body.location || 'Hule Mahjong PIK 2'),
    price: Number(req.body.price) || 0,
    quota: Number(req.body.quota) || 24,
    registered_count: 0,
    image_path: uploaded || '/images/mahjong/event-tournament.jpg',
    excerpt: String(req.body.excerpt || '').trim(),
    description: String(req.body.description || '').trim(),
    is_featured: Boolean(req.body.is_featured),
    is_active: true
  });
  saveDb();
  setFlash(res, 'success', `Event "${title}" published.`);
  res.redirect('/admin/events');
});

app.put('/admin/events/:id', requireAdmin, upload.single('image'), (req, res) => {
  const db = loadDb();
  const ev = db.events.find(e => e.id === Number(req.params.id));
  if (ev) {
    ev.title = String(req.body.title || ev.title).trim();
    ev.category = String(req.body.category || ev.category);
    ev.event_date = String(req.body.event_date || ev.event_date);
    ev.start_time = String(req.body.start_time || ev.start_time);
    ev.end_time = String(req.body.end_time || '');
    ev.price = Number(req.body.price) || 0;
    ev.quota = Number(req.body.quota) || 16;
    ev.location = String(req.body.location || ev.location);
    ev.excerpt = String(req.body.excerpt || '');
    ev.description = String(req.body.description || '');
    ev.is_active = Boolean(req.body.is_active);
    ev.is_featured = Boolean(req.body.is_featured);
    const uploaded = saveUploadedFile(req.file, 'events');
    if (uploaded) ev.image_path = uploaded;
    saveDb();
    setFlash(res, 'success', `Event "${ev.title}" updated.`);
  }
  res.redirect('/admin/events');
});

app.delete('/admin/events/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  db.events = db.events.filter(e => e.id !== Number(req.params.id));
  saveDb();
  setFlash(res, 'success', 'Event deleted.');
  res.redirect('/admin/events');
});

// Admin Gallery
app.get('/admin/gallery', requireAdmin, async (req, res) => {
  const db = loadDb();
  const photos = [...db.galleries]
    .sort((a, b) => (a.sort_order - b.sort_order) || (a.id - b.id))
    .map(hydrateGallery);

  await renderAdmin(res, 'gallery', {
    activeCms: 'gallery',
    title: 'Photo Gallery — Hule Mahjong CMS',
    heading: 'Photo & Media Gallery',
    subheading: 'Upload interior photos, VIP room showcases, tournament snapshots, and F&B imagery.',
    photos
  });
});

app.post('/admin/gallery', requireAdmin, upload.single('image'), (req, res) => {
  const db = loadDb();
  const uploaded = saveUploadedFile(req.file, 'gallery');
  const extUrl = String(req.body.image_url || '').trim();
  db.galleries.push({
    id: nextId('gallery'),
    title: String(req.body.title || 'Lounge Photo').trim(),
    category: String(req.body.category || 'Lounge & Interior'),
    caption: String(req.body.caption || '').trim(),
    image_path: uploaded || extUrl || '/images/mahjong/lounge-regular.jpg',
    is_featured: true,
    is_active: true,
    sort_order: db.galleries.length + 1
  });
  saveDb();
  setFlash(res, 'success', 'Photo added to gallery.');
  res.redirect('/admin/gallery');
});

app.put('/admin/gallery/:id', requireAdmin, upload.single('image'), (req, res) => {
  const db = loadDb();
  const g = db.galleries.find(x => x.id === Number(req.params.id));
  if (g) {
    g.title = String(req.body.title || g.title).trim();
    g.category = String(req.body.category || g.category);
    g.sort_order = Number(req.body.sort_order) || 1;
    g.caption = String(req.body.caption || '').trim();
    g.is_active = Boolean(req.body.is_active);
    const uploaded = saveUploadedFile(req.file, 'gallery');
    if (uploaded) g.image_path = uploaded;
    saveDb();
    setFlash(res, 'success', 'Gallery photo updated.');
  }
  res.redirect('/admin/gallery');
});

app.delete('/admin/gallery/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  db.galleries = db.galleries.filter(x => x.id !== Number(req.params.id));
  saveDb();
  setFlash(res, 'success', 'Photo deleted.');
  res.redirect('/admin/gallery');
});

// Admin Memberships
app.get('/admin/memberships', requireAdmin, async (req, res) => {
  const db = loadDb();
  const plans = [...db.membershipPlans].sort((a, b) => a.sort_order - b.sort_order).map(hydratePlan);
  const applications = db.membershipApplications.map(a => ({
    ...a,
    plan: db.membershipPlans.find(p => p.id === a.membership_plan_id) || null
  }));

  await renderAdmin(res, 'memberships', {
    activeCms: 'memberships',
    title: 'Memberships — Hule Mahjong CMS',
    heading: 'Membership Tiers & Applications',
    subheading: 'Configure patron privileges, pricing, and approve incoming member applications.',
    headerActions: `<button type="button" onclick="document.getElementById('new-plan-panel').classList.toggle('hidden')" class="px-4 py-2 rounded-full bg-[#111] hover:bg-[#c3b091] text-white hover:text-[#141310] text-xs font-semibold transition">+ New Membership Tier</button>`,
    plans,
    applications
  });
});

app.post('/admin/memberships/plans', requireAdmin, (req, res) => {
  const db = loadDb();
  const name = String(req.body.name || 'New Tier').trim();
  const benefits = String(req.body.benefits_raw || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean);

  db.membershipPlans.push({
    id: nextId('plan'),
    slug: slugify(name),
    name,
    badge: String(req.body.badge || '').trim(),
    price: Number(req.body.price) || 500000,
    billing_period: String(req.body.billing_period || 'per quarter').trim(),
    description: String(req.body.description || '').trim(),
    benefits,
    is_featured: Boolean(req.body.is_featured),
    is_active: true,
    sort_order: db.membershipPlans.length + 1
  });
  saveDb();
  setFlash(res, 'success', `Membership tier "${name}" created.`);
  res.redirect('/admin/memberships');
});

app.put('/admin/memberships/plans/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  const p = db.membershipPlans.find(x => x.id === Number(req.params.id));
  if (p) {
    p.name = String(req.body.name || p.name).trim();
    p.badge = String(req.body.badge || '').trim();
    p.price = Number(req.body.price) || 0;
    p.billing_period = String(req.body.billing_period || 'per quarter').trim();
    p.description = String(req.body.description || '').trim();
    p.benefits = String(req.body.benefits_raw || '')
      .split(/\r?\n/)
      .map(s => s.trim())
      .filter(Boolean);
    p.is_active = Boolean(req.body.is_active);
    p.is_featured = Boolean(req.body.is_featured);
    saveDb();
    setFlash(res, 'success', `Tier "${p.name}" updated.`);
  }
  res.redirect('/admin/memberships');
});

app.delete('/admin/memberships/plans/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  db.membershipPlans = db.membershipPlans.filter(x => x.id !== Number(req.params.id));
  saveDb();
  setFlash(res, 'success', 'Membership tier deleted.');
  res.redirect('/admin/memberships');
});

app.put('/admin/memberships/applications/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  const a = db.membershipApplications.find(x => x.id === Number(req.params.id));
  if (a) {
    a.status = String(req.body.status || a.status);
    saveDb();
    setFlash(res, 'success', 'Application status updated.');
  }
  res.redirect('/admin/memberships');
});

// Admin Site Settings & Inbox
app.get('/admin/settings', requireAdmin, async (req, res) => {
  const db = loadDb();
  await renderAdmin(res, 'settings', {
    activeCms: 'settings',
    title: 'Site Settings & Inbox — Hule Mahjong CMS',
    heading: 'Website Content Settings & Concierge Inbox',
    subheading: 'Customize brand identity, CTA banner copy & background image, payment bank account, and read guest inquiries.',
    settings: db.siteSettings,
    inquiries: db.inquiries
  });
});

app.post('/admin/settings', requireAdmin, upload.single('banner_image_file'), (req, res) => {
  const db = loadDb();
  const keys = [
    'brand_prefix', 'brand_suffix', 'cancellation_note', 'house_policy',
    'banner_eyebrow', 'banner_title_line1_bold', 'banner_title_line1_light',
    'banner_title_line2_light', 'banner_title_line2_bold', 'banner_description',
    'contact_address', 'contact_phone', 'contact_whatsapp', 'contact_email',
    'opening_hours', 'payment_bank_name', 'payment_account_number', 'payment_account_holder'
  ];
  for (const k of keys) {
    if (req.body[k] !== undefined) {
      db.siteSettings[k] = String(req.body[k]);
    }
  }
  const uploaded = saveUploadedFile(req.file, 'banners');
  if (uploaded) db.siteSettings.banner_image = uploaded;
  saveDb();
  setFlash(res, 'success', 'Website settings updated.');
  res.redirect('/admin/settings');
});

app.post('/admin/inquiries/:id/read', requireAdmin, (req, res) => {
  const db = loadDb();
  const inq = db.inquiries.find(x => x.id === Number(req.params.id));
  if (inq) {
    inq.is_read = true;
    saveDb();
  }
  res.redirect('/admin/settings');
});

app.delete('/admin/inquiries/:id', requireAdmin, (req, res) => {
  const db = loadDb();
  db.inquiries = db.inquiries.filter(x => x.id !== Number(req.params.id));
  saveDb();
  setFlash(res, 'success', 'Inquiry deleted.');
  res.redirect('/admin/settings');
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Hule Mahjong JS server running at http://127.0.0.1:${PORT}`);
  });
}

module.exports = app;

# Hule Mahjong JS — Fullstack Node.js Booking System & Admin CMS

Elevated Social Mahjong Lounge Booking System, 1-Page PDF E-Pass, and Full Admin CMS built in **Node.js + Express + EJS** (1:1 duplicate of the Laravel edition, engineered for zero-config cloud demos on **Vercel** & **Render**).

Powered by **BENCHCODE™** (`benchcode.dev`).

## Run Locally
```bash
npm install
npm start
```
Open `http://127.0.0.1:3000`
- **Admin CMS**: `http://127.0.0.1:3000/admin/login`
- **Email**: `admin@hulemahjong.id`
- **Password**: `password123`
